DROP TABLE [dbo].[CustomerDemographics]
GO
