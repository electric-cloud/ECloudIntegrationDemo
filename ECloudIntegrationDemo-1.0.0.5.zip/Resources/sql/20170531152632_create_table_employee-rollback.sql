DROP TABLE [dbo].[Employees]
GO
