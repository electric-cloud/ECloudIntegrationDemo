DROP TABLE [dbo].[Region]
GO
